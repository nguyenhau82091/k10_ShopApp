package com.example.settings_screen_tutorial2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
